WALIX MD 7.3 FIX

DOCUMENTATION
https://app.velixs.com/item/whatsapp-gateway-md